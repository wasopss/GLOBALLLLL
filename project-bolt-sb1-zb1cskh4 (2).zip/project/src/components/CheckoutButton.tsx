import { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { STRIPE_PRODUCTS } from '../stripe-config';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

interface CheckoutButtonProps {
  priceId: keyof typeof STRIPE_PRODUCTS;
  children: React.ReactNode;
  className?: string;
}

export function CheckoutButton({ priceId, children, className = '' }: CheckoutButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleCheckout = async () => {
    try {
      setIsLoading(true);
      toast.loading('Preparing your checkout...');

      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session) {
        toast.error('Please sign in to continue with checkout');
        return;
      }

      const stripe = await stripePromise;
      if (!stripe) {
        toast.error('Payment system is currently unavailable');
        return;
      }

      const product = STRIPE_PRODUCTS[priceId];
      if (!product) {
        toast.error('Invalid product selected');
        return;
      }

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/stripe-checkout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          price_id: product.priceId,
          success_url: `${window.location.origin}/success`,
          cancel_url: `${window.location.origin}/#pricing`,
          mode: product.mode,
        }),
      });

      const { error, url } = await response.json();

      if (error) {
        toast.error(error);
        return;
      }

      if (!url) {
        toast.error('Unable to initiate checkout');
        return;
      }

      toast.success('Redirecting to checkout...');
      window.location.href = url;
    } catch (error) {
      console.error('Checkout error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to initiate checkout');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={handleCheckout}
      disabled={isLoading}
      className={`relative w-full py-3 px-6 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    >
      {isLoading ? (
        <>
          <Loader2 className="w-5 h-5 animate-spin absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" />
          <span className="opacity-0">Processing...</span>
        </>
      ) : children}
    </button>
  );
}