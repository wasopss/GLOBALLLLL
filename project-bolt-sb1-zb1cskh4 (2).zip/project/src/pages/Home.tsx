import React, { useState } from 'react';
import { Heart, Dumbbell, Brain, ShieldCheck, CheckCircle2, ArrowRight, Star, Users, Trophy, Clock, Award } from 'lucide-react';
import { CheckoutButton } from '../components/CheckoutButton';
import { STRIPE_PRODUCTS } from '../stripe-config';
import { UserMenu } from '../components/UserMenu';

export function Home() {
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Fitness Enthusiast",
      content: "Healthyou+ transformed my approach to fitness. The lifetime access to personalized plans and expert guidance helped me achieve results I never thought possible.",
      rating: 5,
      image: "https://images.pexels.com/photos/1480520/pexels-photo-1480520.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      name: "Michael Chen",
      role: "Business Professional",
      content: "As a busy professional, I love how Healthyou+ gives me lifetime access to maintain a healthy lifestyle. Best investment I've made in my health journey.",
      rating: 5,
      image: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150"
    },
    {
      name: "Emma Rodriguez",
      role: "Wellness Journey",
      content: "The mental wellness resources and nutrition guidance have been game-changing. One-time payment for lifetime access is incredible value!",
      rating: 5,
      image: "https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg?auto=compress&cs=tinysrgb&w=150"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Heart className="w-8 h-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-800">Healthyou+</span>
          </div>
          <div className="hidden md:flex space-x-8">
            <a href="#features" className="text-gray-600 hover:text-blue-600 transition-colors">Features</a>
            <a href="#testimonials" className="text-gray-600 hover:text-blue-600 transition-colors">Testimonials</a>
            <a href="#pricing" className="text-gray-600 hover:text-blue-600 transition-colors">Pricing</a>
          </div>
          <UserMenu />
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/4498464/pexels-photo-4498464.jpeg?auto=compress&cs=tinysrgb&w=1920"
            alt="Professional trainer helping with exercise"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/50" />
        </div>

        <div className="container mx-auto px-6 py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Transform Your Life with Expert Health Guidance
            </h1>
            <p className="text-xl text-gray-200 mb-8 leading-relaxed">
              Join thousands who have already transformed their lives. Get lifetime access to premium health resources, personalized wellness plans, and expert guidance starting from just €4.90.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <a 
                href="#pricing" 
                className="w-full sm:w-auto px-8 py-4 text-lg font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-all transform hover:scale-105 flex items-center justify-center"
              >
                Start Your Journey
                <ArrowRight className="ml-2 w-5 h-5" />
              </a>
              <div className="flex items-center gap-4 bg-white/10 px-6 py-3 rounded-lg backdrop-blur-sm">
                <div className="flex -space-x-2">
                  {[...Array(5)].map((_, i) => (
                    <img
                      key={i}
                      src={`https://images.pexels.com/photos/${[1438081, 1661929, 1542085, 1480520, 1681010][i]}/pexels-photo-${[1438081, 1661929, 1542085, 1480520, 1681010][i]}.jpeg?auto=compress&cs=tinysrgb&w=50`}
                      alt="Member"
                      className="w-8 h-8 rounded-full border-2 border-white object-cover"
                    />
                  ))}
                </div>
                <span className="text-white font-medium">Join 10,000+ members</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="bg-white py-12 border-y border-gray-100">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-6 h-6 text-green-500" />
              <span className="font-semibold">Secure Payment</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-6 h-6 text-blue-500" />
              <span className="font-semibold">Lifetime Access</span>
            </div>
            <div className="flex items-center space-x-2">
              <Award className="w-6 h-6 text-purple-500" />
              <span className="font-semibold">Expert Guidance</span>
            </div>
            <div className="flex items-center space-x-2">
              <Trophy className="w-6 h-6 text-yellow-500" />
              <span className="font-semibold">Proven Results</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Why Choose Healthyou+?</h2>
          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center transform hover:scale-105 transition-transform">
              <div className="mb-6 rounded-xl overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Personalized Fitness"
                  className="w-full h-48 object-cover"
                />
              </div>
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto -mt-12 mb-6 relative z-10 border-4 border-white">
                <Dumbbell className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Personalized Fitness Plans</h3>
              <p className="text-gray-600">Custom workout routines tailored to your goals and fitness level, updated regularly for optimal results.</p>
            </div>
            <div className="text-center transform hover:scale-105 transition-transform">
              <div className="mb-6 rounded-xl overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3822583/pexels-photo-3822583.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Mental Wellness"
                  className="w-full h-48 object-cover"
                />
              </div>
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto -mt-12 mb-6 relative z-10 border-4 border-white">
                <Brain className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Mental Wellness</h3>
              <p className="text-gray-600">Comprehensive mental health resources, including stress management techniques and mindfulness practices.</p>
            </div>
            <div className="text-center transform hover:scale-105 transition-transform">
              <div className="mb-6 rounded-xl overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/4098228/pexels-photo-4098228.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Lifetime Access"
                  className="w-full h-48 object-cover"
                />
              </div>
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto -mt-12 mb-6 relative z-10 border-4 border-white">
                <ShieldCheck className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Lifetime Access</h3>
              <p className="text-gray-600">One-time payment for unlimited, lifetime access to all resources and future updates.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">What Our Members Say</h2>
          <div className="max-w-3xl mx-auto">
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <div className="flex items-center mb-4">
                <div className="flex-shrink-0">
                  <img
                    src={testimonials[testimonialIndex].image}
                    alt={testimonials[testimonialIndex].name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                </div>
                <div className="ml-4">
                  <h4 className="text-xl font-semibold">{testimonials[testimonialIndex].name}</h4>
                  <p className="text-gray-600">{testimonials[testimonialIndex].role}</p>
                </div>
                <div className="ml-auto flex">
                  {[...Array(testimonials[testimonialIndex].rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-700 text-lg italic">"{testimonials[testimonialIndex].content}"</p>
              <div className="flex justify-center mt-6 space-x-2">
                {testimonials.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setTestimonialIndex(i)}
                    className={`w-3 h-3 rounded-full ${i === testimonialIndex ? 'bg-blue-600' : 'bg-gray-300'}`}
                    aria-label={`View testimonial ${i + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Results Gallery */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Transformation Stories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <img src="https://images.pexels.com/photos/4498574/pexels-photo-4498574.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Transformation" className="rounded-lg hover:opacity-90 transition-opacity" />
            <img src="https://images.pexels.com/photos/4498929/pexels-photo-4498929.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Transformation" className="rounded-lg hover:opacity-90 transition-opacity" />
            <img src="https://images.pexels.com/photos/4498603/pexels-photo-4498603.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Transformation" className="rounded-lg hover:opacity-90 transition-opacity" />
            <img src="https://images.pexels.com/photos/4498457/pexels-photo-4498457.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Transformation" className="rounded-lg hover:opacity-90 transition-opacity" />
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-white">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-4">Choose Your Lifetime Plan</h2>
          <p className="text-xl text-center text-gray-600 mb-16">One-time payment, lifetime access. No recurring fees ever.</p>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Basic Plan */}
            <div className="bg-white rounded-2xl shadow-lg p-8 transform hover:scale-105 transition-transform relative">
              <div className="absolute top-0 right-0 bg-green-600 text-white px-4 py-1 rounded-bl-lg rounded-tr-lg text-sm">
                Best Value
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{STRIPE_PRODUCTS.price_basic.name}</h3>
              <div className="mb-6">
                <div className="text-4xl font-bold text-blue-600">€{STRIPE_PRODUCTS.price_basic.price}</div>
                <div className="text-lg text-gray-500">One-time payment</div>
                <div className="text-sm text-green-600 font-semibold">Lifetime Access</div>
              </div>
              <ul className="space-y-4 mb-8">
                {[
                  'Basic workout plans',
                  'Nutrition guidelines',
                  'Community access',
                  'Email support',
                  'Free updates forever'
                ].map((feature) => (
                  <li key={feature} className="flex items-center">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <CheckoutButton priceId="price_basic">
                Get Started Now
              </CheckoutButton>
            </div>

            {/* Premium Plan */}
            <div className="bg-white rounded-2xl shadow-lg p-8 transform hover:scale-105 transition-transform border-2 border-blue-600 relative">
              <div className="absolute top-0 right-0 bg-blue-600 text-white px-4 py-1 rounded-bl-lg rounded-tr-lg text-sm">
                Most Popular
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{STRIPE_PRODUCTS.price_premium.name}</h3>
              <div className="mb-6">
                <div className="text-4xl font-bold text-blue-600">€{STRIPE_PRODUCTS.price_premium.price}</div>
                <div className="text-lg text-gray-500">One-time payment</div>
                <div className="text-sm text-green-600 font-semibold">Lifetime Access</div>
              </div>
              <ul className="space-y-4 mb-8">
                {[
                  'All Basic features',
                  'Personalized meal plans',
                  'Expert consultations',
                  'Progress tracking',
                  'Priority support',
                  'Free updates forever'
                ].map((feature) => (
                  <li key={feature} className="flex items-center">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <CheckoutButton priceId="price_premium">
                Get Premium Access
              </CheckoutButton>
            </div>

            {/* VIP Plan */}
            <div className="bg-white rounded-2xl shadow-lg p-8 transform hover:scale-105 transition-transform">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{STRIPE_PRODUCTS.price_vip.name}</h3>
              <div className="mb-6">
                <div className="text-4xl font-bold text-blue-600">€{STRIPE_PRODUCTS.price_vip.price}</div>
                <div className="text-lg text-gray-500">One-time payment</div>
                <div className="text-sm text-green-600 font-semibold">Lifetime Access</div>
              </div>
              <ul className="space-y-4 mb-8">
                {[
                  'All Premium features',
                  '1-on-1 coaching',
                  'Custom programs',
                  'Advanced analytics',
                  'Weekly check-ins',
                  'VIP support',
                  'Free updates forever'
                ].map((feature) => (
                  <li key={feature} className="flex items-center">
                    <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <CheckoutButton priceId="price_vip">
                Get VIP Access
              </CheckoutButton>
            </div>
          </div>
          <div className="mt-12 text-center">
            <p className="text-gray-600">All plans include lifetime access with no recurring fees. 30-day money-back guarantee.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12">
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <Heart className="w-8 h-8 text-blue-400" />
                <span className="text-2xl font-bold">Healthyou+</span>
              </div>
              <p className="text-gray-400">Transform your life with expert health guidance and personalized wellness plans.</p>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-4">Company</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Careers</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-4">Legal</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Cookie Policy</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-lg mb-4">Support</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">FAQ</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Community</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Healthyou+. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}