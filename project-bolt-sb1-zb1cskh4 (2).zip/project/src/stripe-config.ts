export const STRIPE_PRODUCTS = {
  price_basic: {
    priceId: 'price_1RLpa8FaoiTxn33JTq2yGQw2',
    name: 'Basic Plan',
    description: 'Get started with our basic health and fitness plan',
    price: '4.90',
    mode: 'payment' as const,
  },
  price_premium: {
    priceId: 'price_1RMAzQFaoiTxn33JiWIfgLaC',
    name: 'Premium Plan',
    description: 'Advanced features and personalized guidance',
    price: '9.90',
    mode: 'payment' as const,
  },
  price_vip: {
    priceId: 'price_1RMB49FaoiTxn33JQNAIn1Xt',
    name: 'VIP Plan',
    description: 'Complete health transformation with VIP support',
    price: '14.50',
    mode: 'payment' as const,
  },
} as const;